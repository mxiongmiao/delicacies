package Employee;
#Employee1.pm
use Person9;
use warnings;
use strict;

our @ISA = qw(Person);
